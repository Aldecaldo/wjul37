import styled from "styled-components";

export default function Page({ children }) {
  return <PageTag>{children}</PageTag>;
}

const PageTag = styled.div`
  /* робимо фон градієнтом */
  background: linear-gradient(0deg, #ff7200 30%, #ffffff 60%, #09cf6a 100%);

  /* робимо фон на всю ширину */
  width: 100%;
`;
